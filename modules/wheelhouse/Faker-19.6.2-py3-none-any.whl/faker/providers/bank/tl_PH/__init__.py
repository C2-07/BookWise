from ..en_PH import Provider as EnPhBankProvider


class Provider(EnPhBankProvider):
    """Implement bank provider for ``tl_PH`` locale.

    There is no difference from the ``en_PH`` implementation.
    """

    pass
